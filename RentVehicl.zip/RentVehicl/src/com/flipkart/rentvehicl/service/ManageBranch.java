package com.flipkart.rentvehicl.service;

import java.util.List;

import com.flipkart.rentvehicl.models.Branch;
import com.flipkart.rentvehicl.models.VehicleItem;

public class ManageBranch {
	public void addBranch(final String location, final List<VehicleItem> vehicleItems, InitStore initStore) {
		Branch branch = new Branch(location, vehicleItems);

		List<Branch> branches = initStore.getBranches();
		branches.add(branch);
		initStore.setBranches(branches);
	}

}
