package com.flipkart.rentvehicl.service;

import java.util.ArrayList;
import java.util.List;

import com.flipkart.rentvehicl.models.Branch;
import com.flipkart.rentvehicl.models.Vehicle;

public class InitStore {
	public List<Branch> getBranches() {
		return branches;
	}

	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	private List<Branch> branches;
	private List<Vehicle> vehicles;

	public void init() {

		branches = new ArrayList<Branch>();
		vehicles = new ArrayList<Vehicle>();
	}

}
