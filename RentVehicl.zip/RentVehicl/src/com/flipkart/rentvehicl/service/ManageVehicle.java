package com.flipkart.rentvehicl.service;

import java.util.Date;
import java.util.List;
import java.util.PriorityQueue;

import com.flipkart.rentvehicl.driver.VComp;
import com.flipkart.rentvehicl.models.Branch;
import com.flipkart.rentvehicl.models.Vehicle;
import com.flipkart.rentvehicl.models.VehicleItem;

public class ManageVehicle {
	public void addVehicleToStore(final String name, final Long id) {
		InitStore initStore = new InitStore();
		Vehicle vehicle = new Vehicle(name, id);

		List<Vehicle> vehicles = initStore.getVehicles();
		vehicles.add(vehicle);
		initStore.setVehicles(vehicles);
	}

	public void addVehicleToBranch(final String name, Long vehicleId, int vehicleCount, InitStore initStore) {

		/*
		 * for (Vehicle vehicle : initStore.getVehicles()) {
		 * System.out.println(vehicle.getId() + vehicle.getName()); }
		 */

		List<Branch> branches = initStore.getBranches();
		Branch branchL = null;
		int index = 0;
		int indexB = 0;

		for (int j = 0; j < branches.size(); j++) {
			if (branches.get(j).getLocation().equalsIgnoreCase(name)) {
				branchL = branches.get(j);
				List<VehicleItem> vehicleItems = branchL.getVehicle();

				for (int i = 0; i < vehicleItems.size(); i++) {
					if (vehicleItems.get(i).getId() == vehicleId) {
						VehicleItem vi = vehicleItems.get(i);
						vi.setCount(vi.getCount() + 1);

						vehicleItems.add(vi);
						index = i;
						break;
					}

				}

				vehicleItems.remove(index);
				branchL.setVehicle(vehicleItems);
				indexB = j;
				// branches.remove(branch);
				branches.add(branchL);
				break;

			}
		}

		branches.remove(indexB);

		if (branchL == null) {
			System.out.println(" Error! No branch found by the name");
		}

	}

	public VehicleItem rentVehicle(final String vehicleName, InitStore initSTore, Date bookedFrom, Date bookedTo) {
		VComp vComp = new VComp();
		PriorityQueue<VehicleItem> queue = new PriorityQueue<>(vComp);

		for (int i = 0; i < initSTore.getBranches().size(); i++) {

			List<VehicleItem> vi = initSTore.getBranches().get(i).getVehicle();

			for (int j = 0; j < vi.size(); j++) {
				if (vi.get(j).getName().equalsIgnoreCase(vehicleName)) {
					System.out.println(vi.get(j));
					queue.add(vi.get(j));
				}
			}

		}
		

		return queue.poll();

		/*
		 * for (int i = 0; i < ) {
		 * 
		 * }
		 */

	}

}
