package com.flipkart.rentvehicl.driver;

import java.util.ArrayList;
import java.util.List;

import com.flipkart.rentvehicl.models.Branch;
import com.flipkart.rentvehicl.models.Vehicle;
import com.flipkart.rentvehicl.models.VehicleItem;
import com.flipkart.rentvehicl.service.InitStore;
import com.flipkart.rentvehicl.service.ManageBranch;
import com.flipkart.rentvehicl.service.ManageVehicle;

public class Driver {

	public static void main(String[] args) {

		InitStore initStore = new InitStore();
		initStore.init();

		ManageVehicle manageVehicle = new ManageVehicle();
		ManageBranch manageBranch = new ManageBranch();
		Vehicle suv = new Vehicle("suv", 1L);
		Vehicle bike = new Vehicle("sedan", 2L);
		Vehicle sedan = new Vehicle("suv", 3L);
		Vehicle hback = new Vehicle("hatchback", 4L);

		List<Vehicle> vehicles = initStore.getVehicles();
		vehicles.add(suv);
		vehicles.add(bike);
		vehicles.add(sedan);

		/* Vehicles for gachibowli */
		List<VehicleItem> vehicleItemsG = new ArrayList<VehicleItem>();
		VehicleItem suvGI = new VehicleItem(suv.getName(), suv.getId(), 12.0, 1);
		VehicleItem sedGI = new VehicleItem(sedan.getName(), sedan.getId(), 10.0, 3);
		VehicleItem bikeGI = new VehicleItem(bike.getName(), bike.getId(), 20.0, 3);
		vehicleItemsG.add(suvGI);
		vehicleItemsG.add(sedGI);
		vehicleItemsG.add(bikeGI);

		List<VehicleItem> vehicleItemsK = new ArrayList<VehicleItem>();
		VehicleItem hbackKI = new VehicleItem(hback.getName(), hback.getId(), 8.0, 4);
		VehicleItem sedKI = new VehicleItem(sedan.getName(), sedan.getId(), 11.0, 3);
		VehicleItem bikeKI = new VehicleItem(bike.getName(), bike.getId(), 20.0, 3);
		vehicleItemsK.add(hbackKI);
		vehicleItemsK.add(sedKI);
		vehicleItemsK.add(bikeKI);

		List<VehicleItem> vehicleItemsM = new ArrayList<VehicleItem>();
		VehicleItem suvMI = new VehicleItem(suv.getName(), suv.getId(), 11.0, 1);
		VehicleItem sedMI = new VehicleItem(sedan.getName(), sedan.getId(), 10.0, 3);
		VehicleItem bikeMI = new VehicleItem(bike.getName(), bike.getId(), 30.0, 10);
		vehicleItemsK.add(suvMI);
		vehicleItemsK.add(sedMI);
		vehicleItemsK.add(bikeMI);

		manageBranch.addBranch("gachibowli", vehicleItemsG, initStore);
		manageBranch.addBranch("kukatpally", vehicleItemsK, initStore);
		manageBranch.addBranch("miyapur", vehicleItemsG, initStore);

		VehicleItem sedGIU = new VehicleItem(sedan.getName(), sedan.getId(), 10.0, 3);

		manageVehicle.addVehicleToBranch("gachibowli", 2L, 1, initStore);
		
		
		System.out.println(manageVehicle.rentVehicle("suv", initStore, null , null).getName());

	}

}
