package com.flipkart.rentvehicl.driver;

import java.util.Comparator;

import com.flipkart.rentvehicl.models.VehicleItem;

public class VComp implements Comparator<VehicleItem>{
	@Override
	public int compare(VehicleItem o1, VehicleItem o2) {

		return o1.getPricePerHour().compareTo(o2.getPricePerHour());
	}

}
