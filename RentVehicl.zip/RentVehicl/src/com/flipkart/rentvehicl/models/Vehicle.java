package com.flipkart.rentvehicl.models;

public  class Vehicle {
	private String name;
	private Long id;

	public Vehicle(String name, Long id) {
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}
}
