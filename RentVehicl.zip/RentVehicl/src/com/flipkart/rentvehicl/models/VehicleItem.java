package com.flipkart.rentvehicl.models;

import java.util.Comparator;
import java.util.Date;

public class VehicleItem extends Vehicle  {
	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	private Integer count;
	private Date bookedFrom;
	private Date bookedTo;

	public VehicleItem(String name, Long id, Double pricePerHour, Integer count) {
		super(name, id);
		this.pricePerHour = pricePerHour;
		this.count = count;
		// TODO Auto-generated constructor stub
	}

	public Date getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	private Double pricePerHour;

	public Double getPricePerHour() {
		return pricePerHour;
	}

	public void setPricePerHour(Double pricePerHour) {
		this.pricePerHour = pricePerHour;
	}

	

	@Override
	public String toString() {
		return "VehicleItem [count=" + count + ", bookedFrom=" + bookedFrom + ", bookedTo=" + bookedTo
				+ ", pricePerHour=" + pricePerHour + "]";
	}

	

}
