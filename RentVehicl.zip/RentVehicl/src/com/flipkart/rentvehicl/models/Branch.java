package com.flipkart.rentvehicl.models;

import java.util.List;

public class Branch {
	public Branch(String location, List<VehicleItem> vehicleItems) {
		super();
		this.location = location;
		this.vehicleItems = vehicleItems;
	}

	private String location;
	private List<VehicleItem> vehicleItems;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<VehicleItem> getVehicle() {
		return vehicleItems;
	}

	public void setVehicle(List<VehicleItem> vehicle) {
		this.vehicleItems = vehicleItems;
	}

}
